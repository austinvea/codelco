const router = require('express').Router();         //accedemos a las rutas definidas para el servidor
const Trabajadores = require('../modelos/Trabajadores');    //utilizamos el esquema de Animales

router.get('/', (req,res) =>{           //ruta GET inicial
    res.redirect('todos');               //redireccionado a la vista inicio.hbs
});

router.get('/todos', async (req,res) =>{                //ruta GET para todos los animales                             
    const trabajadores = await Trabajadores.find().lean();      //busca en la BD todos los animales  
    res.render('todos', {trabajadores});                    //redireccionado a la vista todos.hbs
});

router.get('/primer', async (req,res) =>{               //ruta GET para encontrar un solo animal            
    const trabajador = await Trabajadores.findOne().lean();     //busca en la BD todos los animales 
    res.render('primer', {trabajador});                     //redireccionado a la vista inicio.hbs
});

router.get('/todos/estado/:est', async (req,res) =>{    //ruta GET para todos los animales filtrando por estado
    const trabajadores = await Trabajadores.find({'origen.estado':req.params.est}).lean();      
                //busca filtando por el parámetro que recibe por :esp en la ruta  (se para por req.params.est)
    res.render('todos', {trabajadores});                    //redireccionado a la vista todos.hbs (pero filtada)
});

router.get('/paises', async (req,res) =>{                //ruta GET para todos los paises                             
    const paises = await Trabajadores.distinct('origen.pais');      //busca los distintos paises  
    res.render('paises', {paises});                    //redireccionado a la vista paises.hbs
});

router.get('/todos/pais/:pais', async (req,res) =>{    //ruta GET para todos los animales filtrando por pais
    const trabajadores = await Trabajadores.find({'origen.pais':req.params.pais}).lean();      
                //busca filtando por el parámetro que recibe por :pais en la ruta  (se para por req.params.pais)
    res.render('todos', {trabajadores});                    //redireccionado a la vista todos.hbs (pero filtada)
});

router.get('/todos/ordenadoA', async (req,res) =>{      //ruta GET para todos los animales ordenados                            
    const trabajadores = await Trabajadores.find().sort({nombre:1}).lean();      //ordena ascendentemente los animales  
    res.render('todos', {trabajadores});                    //redireccionado a la vista todos.hbs
});

router.get('/todos/ordenadoB', async (req,res) =>{      //ruta GET para todos los animales ordenados                            
    const trabajadores = await Trabajadores.find().sort({nombre:-1}).lean();      //ordena descendentemente los animales  
    res.render('todos', {trabajadores});                    //redireccionado a la vista todos.hbs
});


module.exports = router;           //exporta las rutas para ser utilizada por otras páginas